﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace LibraryManagemenSystem
{
    public class Book

    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30");


        public int ID { get; set; }
        public string BookTitle { get;set; }

        public string Author { get;set; }

        public string ISBN { get; set; }

        public string Status { get; set; }

        public string Image { get; set; }

        public int Copies { get; set; }

        public List<Book> addBookData()
        {
            List<Book> books = new List<Book>();

            if(connect.State !=ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT * FROM books";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                      SqlDataReader reader = cmd.ExecuteReader();
                       
                        while (reader.Read())
                        {
                            Book book = new Book();
                            book.ID = (int)reader["id"];
                            book.BookTitle = reader["book_title"].ToString();
                            book.Author = reader["author"].ToString();
                            book.ISBN = reader["ISBN"].ToString();
                            book.Status = reader["status"].ToString();
                            book.Image = reader["image"].ToString();
                            book.Copies = (int)reader["copies"];

                           books.Add(book);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex) 
                {
                    Console.WriteLine("Error connecting to database"+ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return books;
           
        }


    }
}
