﻿namespace LibraryManagemenSystem
{
    partial class BorrowBooks
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label1 = new Label();
            label2 = new Label();
            borrowbook_btn = new Button();
            borrowbookssearch_txt = new TextBox();
            returnimage = new PictureBox();
            borrowdatagridview = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)returnimage).BeginInit();
            ((System.ComponentModel.ISupportInitialize)borrowdatagridview).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(128, 0, 32);
            label1.Location = new Point(89, 16);
            label1.Name = "label1";
            label1.Size = new Size(149, 19);
            label1.TabIndex = 2;
            label1.Text = "All Issued Books:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(128, 0, 32);
            label2.Location = new Point(79, 360);
            label2.Name = "label2";
            label2.Size = new Size(70, 19);
            label2.TabIndex = 16;
            label2.Text = "Search:";
            // 
            // borrowbook_btn
            // 
            borrowbook_btn.BackColor = Color.FromArgb(128, 0, 32);
            borrowbook_btn.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            borrowbook_btn.ForeColor = Color.WhiteSmoke;
            borrowbook_btn.Location = new Point(240, 432);
            borrowbook_btn.Name = "borrowbook_btn";
            borrowbook_btn.Size = new Size(103, 43);
            borrowbook_btn.TabIndex = 17;
            borrowbook_btn.Text = "Borrow";
            borrowbook_btn.UseVisualStyleBackColor = false;
            borrowbook_btn.Click += borrowbook_btn_Click;
            // 
            // borrowbookssearch_txt
            // 
            borrowbookssearch_txt.BorderStyle = BorderStyle.FixedSingle;
            borrowbookssearch_txt.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            borrowbookssearch_txt.Location = new Point(167, 358);
            borrowbookssearch_txt.Name = "borrowbookssearch_txt";
            borrowbookssearch_txt.Size = new Size(165, 27);
            borrowbookssearch_txt.TabIndex = 18;
            borrowbookssearch_txt.TextChanged += borrowbookssearch_txt_TextChanged;
            // 
            // returnimage
            // 
            returnimage.Location = new Point(490, 349);
            returnimage.Name = "returnimage";
            returnimage.Size = new Size(127, 143);
            returnimage.SizeMode = PictureBoxSizeMode.Zoom;
            returnimage.TabIndex = 14;
            returnimage.TabStop = false;
            // 
            // borrowdatagridview
            // 
            borrowdatagridview.AllowUserToAddRows = false;
            borrowdatagridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle1.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            borrowdatagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            borrowdatagridview.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(128, 0, 32);
            dataGridViewCellStyle2.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            borrowdatagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            borrowdatagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            borrowdatagridview.DefaultCellStyle = dataGridViewCellStyle3;
            borrowdatagridview.EnableHeadersVisualStyles = false;
            borrowdatagridview.Location = new Point(65, 53);
            borrowdatagridview.Name = "borrowdatagridview";
            borrowdatagridview.ReadOnly = true;
            borrowdatagridview.RowHeadersVisible = false;
            borrowdatagridview.Size = new Size(726, 235);
            borrowdatagridview.TabIndex = 19;
            borrowdatagridview.CellContentClick += borrowdatagridview_CellContentClick;
            // 
            // BorrowBooks
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            Controls.Add(borrowdatagridview);
            Controls.Add(borrowbookssearch_txt);
            Controls.Add(borrowbook_btn);
            Controls.Add(label2);
            Controls.Add(returnimage);
            Controls.Add(label1);
            Name = "BorrowBooks";
            Size = new Size(880, 565);
            ((System.ComponentModel.ISupportInitialize)returnimage).EndInit();
            ((System.ComponentModel.ISupportInitialize)borrowdatagridview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label label2;
        private Button borrowbook_btn;
        private TextBox borrowbookssearch_txt;
        private PictureBox returnimage;
        private DataGridView borrowdatagridview;
    }
}
