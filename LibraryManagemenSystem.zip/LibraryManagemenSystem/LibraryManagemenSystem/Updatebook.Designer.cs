﻿namespace LibraryManagemenSystem
{
    partial class Updatebook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            label1 = new Label();
            label3 = new Label();
            updateauthor_txt = new Label();
            updatebookisbn_txt = new Label();
            updatebooktitle_txt = new TextBox();
            updateauthor_textbx = new TextBox();
            updateisbntextbx = new TextBox();
            addbook_btn = new Button();
            updatebook_btn = new Button();
            deletebook_btn = new Button();
            addbook_picture = new PictureBox();
            button1 = new Button();
            updategridview = new DataGridView();
            updatedataGridView1 = new DataGridView();
            dataGridView1 = new DataGridView();
            Updateclear_btn = new Button();
            numericUpDown1 = new NumericUpDown();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)addbook_picture).BeginInit();
            ((System.ComponentModel.ISupportInitialize)updategridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)updatedataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(128, 0, 32);
            label1.Location = new Point(69, 13);
            label1.Name = "label1";
            label1.Size = new Size(149, 19);
            label1.TabIndex = 1;
            label1.Text = "All Issued Books:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(128, 0, 32);
            label3.Location = new Point(41, 331);
            label3.Name = "label3";
            label3.Size = new Size(99, 19);
            label3.TabIndex = 3;
            label3.Text = "Book Title:";
            label3.Click += label3_Click;
            // 
            // updateauthor_txt
            // 
            updateauthor_txt.AutoSize = true;
            updateauthor_txt.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            updateauthor_txt.ForeColor = Color.FromArgb(128, 0, 32);
            updateauthor_txt.Location = new Point(399, 330);
            updateauthor_txt.Name = "updateauthor_txt";
            updateauthor_txt.Size = new Size(71, 19);
            updateauthor_txt.TabIndex = 5;
            updateauthor_txt.Text = "Author:";
            // 
            // updatebookisbn_txt
            // 
            updatebookisbn_txt.AutoSize = true;
            updatebookisbn_txt.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            updatebookisbn_txt.ForeColor = Color.FromArgb(128, 0, 32);
            updatebookisbn_txt.Location = new Point(389, 381);
            updatebookisbn_txt.Name = "updatebookisbn_txt";
            updatebookisbn_txt.Size = new Size(101, 19);
            updatebookisbn_txt.TabIndex = 6;
            updatebookisbn_txt.Text = "Book ISBN:";
            // 
            // updatebooktitle_txt
            // 
            updatebooktitle_txt.Location = new Point(146, 332);
            updatebooktitle_txt.Name = "updatebooktitle_txt";
            updatebooktitle_txt.Size = new Size(151, 23);
            updatebooktitle_txt.TabIndex = 7;
            // 
            // updateauthor_textbx
            // 
            updateauthor_textbx.Location = new Point(486, 331);
            updateauthor_textbx.Name = "updateauthor_textbx";
            updateauthor_textbx.Size = new Size(151, 23);
            updateauthor_textbx.TabIndex = 8;
            // 
            // updateisbntextbx
            // 
            updateisbntextbx.Location = new Point(486, 382);
            updateisbntextbx.Name = "updateisbntextbx";
            updateisbntextbx.Size = new Size(151, 23);
            updateisbntextbx.TabIndex = 9;
            // 
            // addbook_btn
            // 
            addbook_btn.BackColor = Color.FromArgb(128, 0, 32);
            addbook_btn.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addbook_btn.ForeColor = Color.WhiteSmoke;
            addbook_btn.Location = new Point(374, 428);
            addbook_btn.Name = "addbook_btn";
            addbook_btn.Size = new Size(81, 36);
            addbook_btn.TabIndex = 10;
            addbook_btn.Text = "Add";
            addbook_btn.UseVisualStyleBackColor = false;
            addbook_btn.Click += addbook_btn_Click;
            // 
            // updatebook_btn
            // 
            updatebook_btn.BackColor = Color.FromArgb(128, 0, 32);
            updatebook_btn.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            updatebook_btn.ForeColor = Color.WhiteSmoke;
            updatebook_btn.Location = new Point(476, 428);
            updatebook_btn.Name = "updatebook_btn";
            updatebook_btn.Size = new Size(81, 36);
            updatebook_btn.TabIndex = 11;
            updatebook_btn.Text = "Update";
            updatebook_btn.UseVisualStyleBackColor = false;
            updatebook_btn.Click += updatebook_btn_Click;
            // 
            // deletebook_btn
            // 
            deletebook_btn.BackColor = Color.FromArgb(128, 0, 32);
            deletebook_btn.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deletebook_btn.ForeColor = Color.WhiteSmoke;
            deletebook_btn.Location = new Point(576, 428);
            deletebook_btn.Name = "deletebook_btn";
            deletebook_btn.Size = new Size(81, 36);
            deletebook_btn.TabIndex = 12;
            deletebook_btn.Text = "Delete";
            deletebook_btn.UseVisualStyleBackColor = false;
            deletebook_btn.Click += deletebook_btn_Click;
            // 
            // addbook_picture
            // 
            addbook_picture.Location = new Point(706, 314);
            addbook_picture.Name = "addbook_picture";
            addbook_picture.Size = new Size(100, 114);
            addbook_picture.SizeMode = PictureBoxSizeMode.Zoom;
            addbook_picture.TabIndex = 13;
            addbook_picture.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(128, 0, 32);
            button1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.WhiteSmoke;
            button1.Location = new Point(706, 428);
            button1.Name = "button1";
            button1.Size = new Size(100, 28);
            button1.TabIndex = 16;
            button1.Text = "Import";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // updategridview
            // 
            dataGridViewCellStyle1.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle1.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            updategridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            updategridview.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(128, 0, 32);
            dataGridViewCellStyle2.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            updategridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            updategridview.DefaultCellStyle = dataGridViewCellStyle3;
            updategridview.EnableHeadersVisualStyles = false;
            updategridview.Location = new Point(41, 48);
            updategridview.Name = "updategridview";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            updategridview.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            updategridview.RowHeadersVisible = false;
            updategridview.Size = new Size(0, 0);
            updategridview.TabIndex = 0;
            updategridview.CellContentClick += dataGridView1_CellContentClick;
            // 
            // updatedataGridView1
            // 
            dataGridViewCellStyle5.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle5.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            updatedataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            updatedataGridView1.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(128, 0, 32);
            dataGridViewCellStyle6.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            updatedataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            updatedataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle7.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle7.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            updatedataGridView1.DefaultCellStyle = dataGridViewCellStyle7;
            updatedataGridView1.EnableHeadersVisualStyles = false;
            updatedataGridView1.Location = new Point(69, 48);
            updatedataGridView1.Name = "updatedataGridView1";
            dataGridViewCellStyle8.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle8.Font = new Font("Microsoft Sans Serif", 8.25F);
            updatedataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle8;
            updatedataGridView1.Size = new Size(0, 0);
            updatedataGridView1.TabIndex = 17;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle9.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle9.ForeColor = Color.Black;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            dataGridView1.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = Color.FromArgb(128, 0, 32);
            dataGridViewCellStyle10.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle10.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle10.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle11.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle11.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle11.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle11;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.Location = new Point(69, 48);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Size = new Size(726, 235);
            dataGridView1.TabIndex = 18;
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // Updateclear_btn
            // 
            Updateclear_btn.BackColor = Color.FromArgb(128, 0, 32);
            Updateclear_btn.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Updateclear_btn.ForeColor = Color.WhiteSmoke;
            Updateclear_btn.Location = new Point(476, 479);
            Updateclear_btn.Name = "Updateclear_btn";
            Updateclear_btn.Size = new Size(81, 36);
            Updateclear_btn.TabIndex = 19;
            Updateclear_btn.Text = "Clear";
            Updateclear_btn.UseVisualStyleBackColor = false;
            Updateclear_btn.Click += Updateclear_btn_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(131, 386);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(151, 23);
            numericUpDown1.TabIndex = 20;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(128, 0, 32);
            label2.Location = new Point(41, 386);
            label2.Name = "label2";
            label2.Size = new Size(69, 19);
            label2.TabIndex = 21;
            label2.Text = "Copies:";
            // 
            // Updatebook
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            Controls.Add(label2);
            Controls.Add(numericUpDown1);
            Controls.Add(Updateclear_btn);
            Controls.Add(dataGridView1);
            Controls.Add(updatedataGridView1);
            Controls.Add(button1);
            Controls.Add(addbook_picture);
            Controls.Add(deletebook_btn);
            Controls.Add(updatebook_btn);
            Controls.Add(addbook_btn);
            Controls.Add(updateisbntextbx);
            Controls.Add(updateauthor_textbx);
            Controls.Add(updatebooktitle_txt);
            Controls.Add(updatebookisbn_txt);
            Controls.Add(updateauthor_txt);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(updategridview);
            ForeColor = Color.WhiteSmoke;
            Name = "Updatebook";
            Size = new Size(880, 565);
            Load += Updatebook_Load;
            ((System.ComponentModel.ISupportInitialize)addbook_picture).EndInit();
            ((System.ComponentModel.ISupportInitialize)updategridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)updatedataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label label3;
        private Label updateauthor_txt;
        private Label updatebookisbn_txt;
        private TextBox updatebooktitle_txt;
        private TextBox updateauthor_textbx;
        private TextBox updateisbntextbx;
        private Button addbook_btn;
        private Button updatebook_btn;
        private Button deletebook_btn;
        private PictureBox addbook_picture;
        private Button button1;
        private DataGridView updategridview;
        private DataGridView updatedataGridView1;
        private DataGridView dataGridView1;
        private Button Updateclear_btn;
        private NumericUpDown numericUpDown1;
        private Label label2;
    }
}
