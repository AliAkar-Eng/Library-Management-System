﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Text.RegularExpressions;

namespace LibraryManagemenSystem
{
    public partial class Updatebook : UserControl

    {


        public static string SanitizeFileName(string fileName)
        {
            // Remove invalid characters using Regex
            string invalidCharsPattern = "[" + Regex.Escape(new string(Path.GetInvalidFileNameChars())) + "]";
            return Regex.Replace(fileName, invalidCharsPattern, "_"); // Replace invalid chars with underscore
        }



        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30");
        public Updatebook()
        {
            InitializeComponent();
            displaybook();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Updatebook_Load(object sender, EventArgs e)
        {

        }

        //import button//
        private void button1_Click(object sender, EventArgs e)
        {
            string imagepath = "";
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image Files(*.jpg; *.png)|*jpg;*.png";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    imagepath = dialog.FileName;
                    addbook_picture.ImageLocation = imagepath;

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private void addbook_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(updatebooktitle_txt.Text) ||
                string.IsNullOrWhiteSpace(updateisbntextbx.Text) ||
                string.IsNullOrWhiteSpace(updateauthor_textbx.Text) ||
                addbook_picture.ImageLocation == null)
            {
                MessageBox.Show("Please fill all the blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                string isbn = updateisbntextbx.Text.Trim();
                string checkQuery = "SELECT COUNT(*) FROM books WHERE ISBN = @ISBN";

                connect.Open();
                using (SqlCommand cmd = new SqlCommand(checkQuery, connect))
                {
                    cmd.Parameters.AddWithValue("@ISBN", isbn);
                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("This book already exists in the system.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return; // Exit the method if book exists
                    }
                }
                connect.Close();
                DataGridViewRow row = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex];
                // Sanitize file names
                string bookTitle = SanitizeFileName(updatebooktitle_txt.Text.Trim());
                string author = SanitizeFileName(updateauthor_textbx.Text.Trim());
                string status = ((int)numericUpDown1.Value > 0) ? "Available" : "Unavailable";


                string oldImagePath = row.Cells[5].Value?.ToString(); // Get existing image path
                string newImagePath = oldImagePath; // Default to old image path

                // If a new image is provided, replace the old one
                if (!string.IsNullOrEmpty(addbook_picture.ImageLocation) && addbook_picture.ImageLocation != oldImagePath)
                {
                    newImagePath = Path.Combine(@"C:\c#\LibraryManagemenSystem\LibraryManagemenSystem\Books_Directory\",
                                                bookTitle + "_" + author + ".jpg");

                    if (!string.IsNullOrEmpty(addbook_picture.ImageLocation) && addbook_picture.ImageLocation != oldImagePath)
                    {
                        newImagePath = Path.Combine(@"C:\c#\LibraryManagemenSystem\LibraryManagemenSystem\Books_Directory\",
                                                    bookTitle + "_" + author + ".jpg");

                        // **Fix: Properly release the image before replacing**
                        if (addbook_picture.Image != null)
                        {
                            addbook_picture.Image.Dispose();
                            addbook_picture.Image = null;
                            GC.Collect();
                            GC.WaitForPendingFinalizers();
                        }


                        if (!Directory.Exists(Path.GetDirectoryName(newImagePath)))
                        {
                            Directory.CreateDirectory(Path.GetDirectoryName(newImagePath));
                        }
                        File.Copy(addbook_picture.ImageLocation, newImagePath, true);
                    }


                }



                // Insert book into database
                connect.Open();
                string insertData = "INSERT INTO books (book_title, author, ISBN, status, image, copies) " +
                                    "VALUES (@book_title, @author, @ISBN, @status, @image, @copies)";

                using (SqlCommand cmd = new SqlCommand(insertData, connect))
                {
                    cmd.Parameters.AddWithValue("@book_title", bookTitle);
                    cmd.Parameters.AddWithValue("@author", author);
                    cmd.Parameters.AddWithValue("@ISBN", isbn);
                    cmd.Parameters.AddWithValue("@status", status);
                    cmd.Parameters.AddWithValue("@image", newImagePath);
                    cmd.Parameters.AddWithValue("@copies", numericUpDown1.Value);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Added Successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displaybook();
                clearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connect.Close();
            }
        }


        private void label3_Click(object sender, EventArgs e)
        {

        }
        public void clearFields()
        {
            updatebooktitle_txt.Text = "";
            updateauthor_textbx.Text = "";
            updateisbntextbx.Text = "";
            addbook_picture.Image = null;

            numericUpDown1.Value = 0;
            dataGridView1.Refresh();



        }

        public void displaybook()
        {
            Book book = new Book();
            List<Book> listdata = book.addBookData();
            dataGridView1.DataSource = listdata;
            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
        }
        private int bookID = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.RowIndex >= 0) // Ensure it's a valid row index
                {
                    try
                    {
                        DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                        // Assign values from DataGridView to TextBoxes
                        bookID = Convert.ToInt32(row.Cells[0].Value);
                        updatebooktitle_txt.Text = row.Cells[1].Value?.ToString() ?? "";
                        updateauthor_textbx.Text = row.Cells[2].Value?.ToString() ?? "";
                        updateisbntextbx.Text = row.Cells[3].Value?.ToString() ?? "";



                        // Handle Image Loading Efficiently
                        string imagePath = row.Cells[5].Value?.ToString();
                        if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                        {
                            using (FileStream stream = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                            {
                                addbook_picture.Image = Image.FromStream(stream);
                            }
                            addbook_picture.ImageLocation = imagePath;
                        }

                        else
                        {
                            addbook_picture.Image = null;
                            addbook_picture.ImageLocation = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        dataGridView1.Refresh();
                    }
                }
            }
        }

        private void updatebook_btn_Click(object sender, EventArgs e)
        {
            // Check if all required fields are filled
            if (addbook_picture.ImageLocation == null || updatebooktitle_txt.Text == null || updateisbntextbx.Text == null
                || updateauthor_textbx.Text == null)
            {
                MessageBox.Show("Please select item first ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Check if a row is selected by verifying the CurrentCell
                if (dataGridView1.CurrentCell != null)
                {
                    // Get the selected row
                    DataGridViewRow row = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex];

                    // Ensure row is not null
                    if (row != null)
                    {
                        try
                        {
                            connect.Open();
                            int copies = (int)numericUpDown1.Value;

                            // Sanitize input fields
                            string bookTitle = SanitizeFileName(updatebooktitle_txt.Text.Trim());
                            string author = SanitizeFileName(updateauthor_textbx.Text.Trim());
                            string isbn = SanitizeFileName(updateisbntextbx.Text.Trim());
                            string status = (copies > 0) ? "Available" : "Unavailable";

                            string oldImagePath = row.Cells[5].Value?.ToString(); // Get existing image path
                            string newImagePath = oldImagePath; // Default to old image path

                            // If a new image is provided, replace the old one
                            if (!string.IsNullOrEmpty(addbook_picture.ImageLocation) && addbook_picture.ImageLocation != oldImagePath)
                            {
                                newImagePath = Path.Combine(@"C:\c#\LibraryManagemenSystem\LibraryManagemenSystem\Books_Directory\",
                                                            bookTitle + "_" + author + ".jpg");

                                if (!string.IsNullOrEmpty(addbook_picture.ImageLocation) && addbook_picture.ImageLocation != oldImagePath)
                                {
                                    newImagePath = Path.Combine(@"C:\c#\LibraryManagemenSystem\LibraryManagemenSystem\Books_Directory\",
                                                                bookTitle + "_" + author + ".jpg");

                                    // **Fix: Properly release the image before replacing**
                                    if (addbook_picture.Image != null)
                                    {
                                        addbook_picture.Image.Dispose();
                                        addbook_picture.Image = null;
                                        GC.Collect();
                                        GC.WaitForPendingFinalizers();
                                    }


                                    if (!Directory.Exists(Path.GetDirectoryName(newImagePath)))
                                    {
                                        Directory.CreateDirectory(Path.GetDirectoryName(newImagePath));
                                    }
                                    File.Copy(addbook_picture.ImageLocation, newImagePath, true);
                                }


                            }

                            // Update query
                            string updateData = "UPDATE books SET book_title=@book_title, author=@author, "
                                  + "ISBN=@ISBN, status=@status, image=@image, copies=@copies  WHERE id=@id";

                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@book_title", bookTitle);
                                cmd.Parameters.AddWithValue("@author", author);
                                cmd.Parameters.AddWithValue("@ISBN", isbn);
                                cmd.Parameters.AddWithValue("@status", status);
                                cmd.Parameters.AddWithValue("@image", newImagePath);
                                cmd.Parameters.AddWithValue("@copies", copies);
                                cmd.Parameters.AddWithValue("@id", bookID);

                                cmd.ExecuteNonQuery();

                                MessageBox.Show("Updated Successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                displaybook();
                                clearFields();
                            }


                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                }
                else
                {
                    // If no row is selected
                    MessageBox.Show("Please select a book to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private void Updateclear_btn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void deletebook_btn_Click(object sender, EventArgs e)
        {
            if (addbook_picture.ImageLocation == null || updatebooktitle_txt.Text == null || updateisbntextbx.Text == null
               || updateauthor_textbx.Text == null)
            {
                MessageBox.Show("Please select item first ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else

            {
                if (connect.State != ConnectionState.Open)
                {
                    try
                    {
                        connect.Open();
                        // checking if book exist in borrowed book table//

                        string checkQuery = "SELECT COUNT(*) FROM borrowed_books WHERE book_id = @bookID";
                        using (SqlCommand checkCmd = new SqlCommand(checkQuery, connect))
                        {
                            checkCmd.Parameters.AddWithValue("@bookID", bookID);
                            int count = (int)checkCmd.ExecuteScalar();

                            if (count > 0)
                            {
                                MessageBox.Show("This book cannot be deleted because it has been borrowed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }


                        DialogResult check = MessageBox.Show("Are you sure you want to delete book ID:" +
                            bookID + "?", "Comfirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (check == DialogResult.Yes)
                        {



                            string deleteData = "DELETE FROM books WHERE id=" + bookID;
                            using (SqlCommand cmd = new SqlCommand(deleteData, connect))
                            {
                                cmd.ExecuteNonQuery();

                                MessageBox.Show("Deleted  Successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                displaybook();
                                clearFields();
                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                    
                }

            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
