﻿namespace LibraryManagemenSystem
{
    partial class ManageMember
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label1 = new Label();
            deletemember_btn = new Button();
            membersgridview = new DataGridView();
            adminregister_email = new TextBox();
            label6 = new Label();
            adminregister_password = new TextBox();
            adminregister_username = new TextBox();
            label4 = new Label();
            label3 = new Label();
            adminregister = new Button();
            ((System.ComponentModel.ISupportInitialize)membersgridview).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(128, 0, 32);
            label1.Location = new Point(84, 9);
            label1.Name = "label1";
            label1.Size = new Size(116, 19);
            label1.TabIndex = 2;
            label1.Text = "All Members:";
            label1.Click += label1_Click;
            // 
            // deletemember_btn
            // 
            deletemember_btn.BackColor = Color.FromArgb(128, 0, 32);
            deletemember_btn.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            deletemember_btn.ForeColor = Color.WhiteSmoke;
            deletemember_btn.Location = new Point(314, 492);
            deletemember_btn.Name = "deletemember_btn";
            deletemember_btn.Size = new Size(103, 43);
            deletemember_btn.TabIndex = 15;
            deletemember_btn.Text = "Delete";
            deletemember_btn.UseVisualStyleBackColor = false;
            deletemember_btn.Click += deletemember_btn_Click;
            // 
            // membersgridview
            // 
            membersgridview.AllowUserToAddRows = false;
            membersgridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle1.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            membersgridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            membersgridview.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(128, 0, 32);
            dataGridViewCellStyle2.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            membersgridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            membersgridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            membersgridview.DefaultCellStyle = dataGridViewCellStyle3;
            membersgridview.EnableHeadersVisualStyles = false;
            membersgridview.Location = new Point(56, 48);
            membersgridview.Name = "membersgridview";
            membersgridview.ReadOnly = true;
            membersgridview.RowHeadersVisible = false;
            membersgridview.Size = new Size(726, 235);
            membersgridview.TabIndex = 20;
            membersgridview.CellContentClick += borrowdatagridview_CellContentClick;
            // 
            // adminregister_email
            // 
            adminregister_email.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            adminregister_email.Location = new Point(159, 324);
            adminregister_email.Multiline = true;
            adminregister_email.Name = "adminregister_email";
            adminregister_email.Size = new Size(296, 30);
            adminregister_email.TabIndex = 31;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(128, 0, 32);
            label6.Location = new Point(23, 324);
            label6.Name = "label6";
            label6.Size = new Size(130, 19);
            label6.TabIndex = 30;
            label6.Text = "Email Address:";
            // 
            // adminregister_password
            // 
            adminregister_password.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            adminregister_password.Location = new Point(159, 434);
            adminregister_password.Multiline = true;
            adminregister_password.Name = "adminregister_password";
            adminregister_password.Size = new Size(296, 30);
            adminregister_password.TabIndex = 27;
            // 
            // adminregister_username
            // 
            adminregister_username.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            adminregister_username.Location = new Point(159, 381);
            adminregister_username.Multiline = true;
            adminregister_username.Name = "adminregister_username";
            adminregister_username.Size = new Size(296, 30);
            adminregister_username.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(128, 0, 32);
            label4.Location = new Point(27, 436);
            label4.Name = "label4";
            label4.Size = new Size(93, 19);
            label4.TabIndex = 25;
            label4.Text = "Password:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(128, 0, 32);
            label3.Location = new Point(23, 383);
            label3.Name = "label3";
            label3.Size = new Size(97, 19);
            label3.TabIndex = 24;
            label3.Text = "Username:";
            // 
            // adminregister
            // 
            adminregister.BackColor = Color.FromArgb(128, 0, 32);
            adminregister.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            adminregister.ForeColor = Color.WhiteSmoke;
            adminregister.Location = new Point(168, 492);
            adminregister.Name = "adminregister";
            adminregister.Size = new Size(103, 43);
            adminregister.TabIndex = 32;
            adminregister.Text = "Register";
            adminregister.UseVisualStyleBackColor = false;
            adminregister.Click += adminregister_Click;
            // 
            // ManageMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            Controls.Add(adminregister);
            Controls.Add(adminregister_email);
            Controls.Add(label6);
            Controls.Add(adminregister_password);
            Controls.Add(adminregister_username);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(membersgridview);
            Controls.Add(deletemember_btn);
            Controls.Add(label1);
            Name = "ManageMember";
            Size = new Size(880, 565);
            ((System.ComponentModel.ISupportInitialize)membersgridview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Button deletemember_btn;
        private DataGridView membersgridview;
        private TextBox adminregister_email;
        private Label label6;
        private TextBox adminregister_password;
        private TextBox adminregister_username;
        private Label label4;
        private Label label3;
        private Button adminregister;
    }
}
