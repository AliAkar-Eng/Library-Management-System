﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagemenSystem
{
    public class Member
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30");

        public int ID {  get; set; } 
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public DateTime? DateRegistered { get; set; }
        public List<Book> BorrowedBooks { get; set; } = new List<Book>();

        public List<Member> addmemberdata()
        {
            List<Member> allmembers = new List<Member>();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT * FROM users";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Member member = new Member();
                            member.ID = (int)reader["id"];
                            member.Name = reader["username"].ToString();
                            member.Password = reader["password"].ToString();
                            member.Email = reader["email"].ToString();

                            member.BorrowedBooks = GetBorrowedBooks();


                            allmembers.Add(member);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting to database" + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return allmembers;

        }
        public  List<Book> GetBorrowedBooks()
        {
            List<Book> borrowedBooks = new List<Book>();

            try
            {
                if (connect.State != ConnectionState.Open)
                    connect.Open();

                string query = "SELECT b.id, b.book_title, b.author, b.ISBN, b.status, b.image, b.copies " +
                               "FROM borrowed_books bb " +
                               "JOIN books b ON bb.book_id = b.id " +
                               "WHERE bb.member_id = @memberId";

                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    cmd.Parameters.AddWithValue("@memberId", Session.MemberID);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Book book = new Book();

                        book.ID = (int)reader["id"];
                            book.BookTitle = reader["book_title"].ToString();
                        book.Author = reader["author"].ToString();
                        book.ISBN = reader["ISBN"].ToString();
                        book.Status = reader["status"].ToString();
                        book.Image = reader["image"].ToString();
                        book.Copies = (int)reader["copies"];
                       
                        borrowedBooks.Add(book);
                    }
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error fetching borrowed books: " + ex);
            }
            finally
            {
                connect.Close();
            }

            return borrowedBooks;
        }



    }
}
