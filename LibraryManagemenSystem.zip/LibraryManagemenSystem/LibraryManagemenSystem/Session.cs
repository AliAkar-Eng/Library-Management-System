﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagemenSystem
{
    public static class Session
    {
        public static int MemberID { get; set; }  // Stores logged-in user's ID
    }

}
