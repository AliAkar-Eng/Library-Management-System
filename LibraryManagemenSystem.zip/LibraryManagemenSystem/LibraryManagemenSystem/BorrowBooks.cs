﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagemenSystem
{
    public partial class BorrowBooks : UserControl
    {
        List<Book> allBooks = new List<Book>();

       
        public BorrowBooks()
        {
            InitializeComponent();
            borrowdatagridview.CellClick += borrowdatagridview_CellClick;
            displaybook();
        }
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30");

        private void borrowdatagridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void displaybook()
        {
            Book book = new Book();
            allBooks = book.addBookData();
            borrowdatagridview.DataSource = allBooks;
            borrowdatagridview.DefaultCellStyle.ForeColor = Color.Black;
        }
        public void SearchBook(string searchTerm)
        {
            // Convert search term to lowercase for case-insensitive comparison
            string lowerSearch = searchTerm.ToLower();

            // Filter books where title, ISBN, or author contains the search term
            var filteredBooks = allBooks
                .Where(b => b.BookTitle.ToLower().Contains(lowerSearch) ||
                            b.ISBN.ToLower().Contains(lowerSearch) ||
                            b.Author.ToLower().Contains(lowerSearch))
                .ToList();

            // Update DataGridView with filtered results
            borrowdatagridview.DataSource = filteredBooks;

        }

        private void borrowbookssearch_txt_TextChanged(object sender, EventArgs e)
        {
            SearchBook(borrowbookssearch_txt.Text);
        }

        private void borrowdatagridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.RowIndex >= 0) // Ensure it's a valid row index
                {
                    try
                    {
                        DataGridViewRow row = borrowdatagridview.Rows[e.RowIndex];




                        // Handle Image Loading Efficiently
                        string imagePath = row.Cells[5].Value?.ToString();
                        if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                        {
                            using (FileStream stream = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                            {
                                returnimage.Image = Image.FromStream(stream);
                            }
                            returnimage.ImageLocation = imagePath;
                        }

                        else
                        {
                            returnimage.Image = null;
                            returnimage.ImageLocation = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        borrowdatagridview.Refresh();
                    }
                }
            }
        }
        public void refreshgrid2()
        {
            borrowdatagridview.Refresh();
        }

        private void borrowbook_btn_Click(object sender, EventArgs e)
        {
            if (borrowdatagridview.CurrentCell != null)
            {
                DataGridViewRow row = borrowdatagridview.Rows[borrowdatagridview.CurrentCell.RowIndex];
                if (row != null)
                {

                    try
                    {

                        int bookId = Convert.ToInt32(row.Cells["ID"].Value);
                        int copies = Convert.ToInt32(row.Cells["Copies"].Value);
                        string status = row.Cells["Status"].Value.ToString();

                        if (copies <= 0)
                        {
                            MessageBox.Show("This book is currently unavailable!", "Borrowing Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        int memberId = Session.MemberID; // This now correctly contains the "id" from users table

                        if (memberId == 0)
                        {
                            MessageBox.Show("Error: Member not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        using (SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30"))
                        {
                            connect.Open();

                            string insertQuery = "INSERT INTO borrowed_books (member_id, book_id, borrow_date) VALUES (@memberId, @bookId, GETDATE())";
                            using (SqlCommand cmd = new SqlCommand(insertQuery, connect))
                            {
                                cmd.Parameters.AddWithValue("@memberId", memberId);
                                cmd.Parameters.AddWithValue("@bookId", bookId);
                                cmd.ExecuteNonQuery();
                            }

                            copies--;
                            status = (copies == 0) ? "Unavailable" : "Available";

                            string updateQuery = "UPDATE books SET copies = @copies, status = @status WHERE id = @bookId";
                            using (SqlCommand cmd = new SqlCommand(updateQuery, connect))
                            {
                                cmd.Parameters.AddWithValue("@copies", copies);
                                cmd.Parameters.AddWithValue("@status", status);
                                cmd.Parameters.AddWithValue("@bookId", bookId);
                                cmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Book borrowed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            displaybook(); 


                            // this refresh both tables after borrowing//
                            var borrowBooksControl = this.Parent.Controls.OfType<ReturnBooks>().FirstOrDefault();
                            if (borrowBooksControl != null)
                            {
                                borrowBooksControl.displayBorrowedBooks();
                            }




                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a book to borrow!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }


}  

