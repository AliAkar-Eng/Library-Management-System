﻿namespace LibraryManagemenSystem
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegisterForm));
            register_showPass = new CheckBox();
            signIn_btn = new Button();
            label5 = new Label();
            register_btn = new Button();
            register_password = new TextBox();
            register_username = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label1 = new Label();
            register_email = new TextBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // register_showPass
            // 
            register_showPass.AutoSize = true;
            register_showPass.Font = new Font("Tahoma", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            register_showPass.Location = new Point(191, 388);
            register_showPass.Name = "register_showPass";
            register_showPass.Size = new Size(117, 20);
            register_showPass.TabIndex = 21;
            register_showPass.Text = "Show Password";
            register_showPass.UseVisualStyleBackColor = true;
            register_showPass.CheckedChanged += register_showPass_CheckedChanged;
            // 
            // signIn_btn
            // 
            signIn_btn.BackColor = Color.FromArgb(128, 0, 32);
            signIn_btn.Cursor = Cursors.Hand;
            signIn_btn.FlatAppearance.BorderSize = 0;
            signIn_btn.FlatStyle = FlatStyle.Flat;
            signIn_btn.Font = new Font("Arial Narrow", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signIn_btn.ForeColor = Color.WhiteSmoke;
            signIn_btn.Location = new Point(12, 489);
            signIn_btn.Name = "signIn_btn";
            signIn_btn.Size = new Size(296, 30);
            signIn_btn.TabIndex = 20;
            signIn_btn.Text = "SIGN IN";
            signIn_btn.UseVisualStyleBackColor = false;
            signIn_btn.Click += signIn_btn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(110, 469);
            label5.Name = "label5";
            label5.Size = new Size(101, 14);
            label5.TabIndex = 19;
            label5.Text = "Register Account";
            // 
            // register_btn
            // 
            register_btn.BackColor = Color.FromArgb(128, 0, 32);
            register_btn.Cursor = Cursors.Hand;
            register_btn.FlatAppearance.BorderSize = 0;
            register_btn.FlatStyle = FlatStyle.Flat;
            register_btn.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            register_btn.ForeColor = Color.WhiteSmoke;
            register_btn.Location = new Point(12, 426);
            register_btn.Name = "register_btn";
            register_btn.Size = new Size(296, 40);
            register_btn.TabIndex = 18;
            register_btn.Text = "REGISTER";
            register_btn.UseVisualStyleBackColor = false;
            register_btn.Click += register_btn_Click;
            // 
            // register_password
            // 
            register_password.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            register_password.Location = new Point(12, 352);
            register_password.Multiline = true;
            register_password.Name = "register_password";
            register_password.PasswordChar = '*';
            register_password.Size = new Size(296, 30);
            register_password.TabIndex = 17;
            // 
            // register_username
            // 
            register_username.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            register_username.Location = new Point(12, 298);
            register_username.Multiline = true;
            register_username.Name = "register_username";
            register_username.Size = new Size(296, 30);
            register_username.TabIndex = 16;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(12, 331);
            label4.Name = "label4";
            label4.Size = new Size(74, 18);
            label4.TabIndex = 15;
            label4.Text = "Password:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(12, 277);
            label3.Name = "label3";
            label3.Size = new Size(80, 18);
            label3.TabIndex = 14;
            label3.Text = "Username:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(90, 175);
            label2.Name = "label2";
            label2.Size = new Size(132, 23);
            label2.TabIndex = 13;
            label2.Text = "Registration Form";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(99, 62);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(128, 0, 32);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(320, 35);
            panel1.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(302, 9);
            label1.Name = "label1";
            label1.Size = new Size(15, 15);
            label1.TabIndex = 0;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // register_email
            // 
            register_email.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            register_email.Location = new Point(12, 244);
            register_email.Multiline = true;
            register_email.Name = "register_email";
            register_email.Size = new Size(296, 30);
            register_email.TabIndex = 23;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(12, 223);
            label6.Name = "label6";
            label6.Size = new Size(103, 18);
            label6.TabIndex = 22;
            label6.Text = "Email Address:";
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(320, 525);
            Controls.Add(register_email);
            Controls.Add(label6);
            Controls.Add(register_showPass);
            Controls.Add(signIn_btn);
            Controls.Add(label5);
            Controls.Add(register_btn);
            Controls.Add(register_password);
            Controls.Add(register_username);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RegisterForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RegisterForm";
            Load += RegisterForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox register_showPass;
        private Button signIn_btn;
        private Label label5;
        private Button register_btn;
        private TextBox register_password;
        private TextBox register_username;
        private Label label4;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label1;
        private TextBox register_email;
        private Label label6;
    }
}