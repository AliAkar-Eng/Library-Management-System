﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagemenSystem
{
    public partial class ReturnBooks : UserControl
    {


        public ReturnBooks()
        {
            InitializeComponent();
            returndatagridview.CellClick += returndatagridview_CellClick;
            returnbook_btn.Click += returnbook_btn_Click;

            displayBorrowedBooks();


        }

        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30");

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void returndatagridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void returndatagridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.RowIndex >= 0) // Ensure it's a valid row index
                {
                    try
                    {
                        DataGridViewRow row = returndatagridview.Rows[e.RowIndex];

                        // Assign values from DataGridView to TextBoxes
                        returnissueid_txt.Text = row.Cells[0].Value.ToString() ?? "";

                        returnbooktittle_txt.Text = row.Cells[1].Value?.ToString() ?? "";
                        returnbookisbn_txt.Text = row.Cells[3].Value?.ToString() ?? "";



                        // Handle Image Loading Efficiently
                        string imagePath = row.Cells[5].Value?.ToString();
                        if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                        {
                            using (FileStream stream = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                            {
                                returnpicbox.Image = Image.FromStream(stream);
                            }
                            returnpicbox.ImageLocation = imagePath;
                        }

                        else
                        {
                            returnpicbox.Image = null;
                            returnpicbox.ImageLocation = null;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        returndatagridview.Refresh();
                    }
                }
            }
        }
        public void displayBorrowedBooks()
        {
            List<Book> borrowedBooks = new List<Book>();

            try
            {
                using (SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30"))
                {
                    connect.Open();

                    string query = @"SELECT b.id, b.book_title, b.author, b.ISBN, b.status, b.image, b.copies 
                             FROM borrowed_books bb
                             JOIN books b ON bb.book_id = b.id
                             WHERE bb.member_id = @memberId";

                    using (SqlCommand cmd = new SqlCommand(query, connect))
                    {
                        cmd.Parameters.AddWithValue("@memberId", Session.MemberID);
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Book book = new Book
                            {
                                ID = (int)reader["id"],
                                BookTitle = reader["book_title"].ToString(),
                                Author = reader["author"].ToString(),
                                ISBN = reader["ISBN"].ToString(),
                                Status = reader["status"].ToString(),
                                Image = reader["image"].ToString(),
                                Copies = (int)reader["copies"]
                            };

                            borrowedBooks.Add(book);
                        }
                        reader.Close();
                    }
                }

                returndatagridview.DataSource = borrowedBooks;
                returndatagridview.DefaultCellStyle.ForeColor = Color.Black;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching borrowed books: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void refreshgrid()
        {
            returndatagridview.Refresh();
        }

        public void clearview()
        {
            returnpicbox.Image = null;
            returnissueid_txt.Text = null;
            returnbooktittle_txt.Text = null;
            returnbookisbn_txt.Text = null;
        }

        private void returnbook_btn_Click(object sender, EventArgs e)
        {
            if (returndatagridview.CurrentCell != null)
            {
                DataGridViewRow row = returndatagridview.Rows[returndatagridview.CurrentCell.RowIndex];
                if (row != null)
                {
                    try
                    {
                        int bookId = Convert.ToInt32(row.Cells["ID"].Value);
                        int memberId = Session.MemberID;

                        if (memberId == 0)
                        {
                            MessageBox.Show("Error: Member not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        using (SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30"))
                        {
                            connect.Open();

                            // Check if the user has borrowed this book
                            string checkQuery = "SELECT COUNT(*) FROM borrowed_books WHERE member_id = @memberId AND book_id = @bookId";
                            using (SqlCommand checkCmd = new SqlCommand(checkQuery, connect))
                            {
                                checkCmd.Parameters.AddWithValue("@memberId", memberId);
                                checkCmd.Parameters.AddWithValue("@bookId", bookId);

                                int count = (int)checkCmd.ExecuteScalar();
                                if (count == 0)
                                {
                                    MessageBox.Show("You cannot return a book you haven't borrowed!", "Return Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }
                            }

                            // Remove book from borrowed_books
                            string deleteQuery = "DELETE FROM borrowed_books WHERE member_id = @memberId AND book_id = @bookId";
                            using (SqlCommand deleteCmd = new SqlCommand(deleteQuery, connect))
                            {
                                deleteCmd.Parameters.AddWithValue("@memberId", memberId);
                                deleteCmd.Parameters.AddWithValue("@bookId", bookId);
                                deleteCmd.ExecuteNonQuery();
                            }

                            // Update book copies
                            string updateQuery = "UPDATE books SET copies = copies + 1, status = CASE WHEN copies + 1 > 0 THEN 'Available' ELSE 'Unavailable' END WHERE id = @bookId";
                            using (SqlCommand updateCmd = new SqlCommand(updateQuery, connect))
                            {
                                updateCmd.Parameters.AddWithValue("@bookId", bookId);
                                updateCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Book returned successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            displayBorrowedBooks();
                            clearview();
                            var borrowBooksControl = this.Parent.Controls.OfType<BorrowBooks>().FirstOrDefault();
                            if (borrowBooksControl != null)
                            {
                                borrowBooksControl.displaybook();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a book to return!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void returnpicbox_Click(object sender, EventArgs e)
        {
          
        }
    }
}
