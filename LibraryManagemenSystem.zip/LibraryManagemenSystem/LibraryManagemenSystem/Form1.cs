namespace LibraryManagemenSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel3.Width += 6;

            if (panel3.Width >= 575)
            {
                timer1.Stop();

                LoginForm  lForm = new LoginForm();
                lForm.Show();
                this.Hide();
            }
        }
    }
}
