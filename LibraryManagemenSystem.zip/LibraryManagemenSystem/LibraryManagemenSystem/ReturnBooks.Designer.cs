﻿namespace LibraryManagemenSystem
{
    partial class ReturnBooks
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel1 = new Panel();
            returnpicbox = new PictureBox();
            label4 = new Label();
            label3 = new Label();
            returnbook_btn = new Button();
            returnbookisbn_txt = new TextBox();
            returnbooktittle_txt = new TextBox();
            returnissueid_txt = new TextBox();
            label2 = new Label();
            panel2 = new Panel();
            returndatagridview = new DataGridView();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)returnpicbox).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)returndatagridview).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(returnpicbox);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(returnbook_btn);
            panel1.Controls.Add(returnbookisbn_txt);
            panel1.Controls.Add(returnbooktittle_txt);
            panel1.Controls.Add(returnissueid_txt);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(13, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(245, 516);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint_1;
            // 
            // returnpicbox
            // 
            returnpicbox.Location = new Point(66, 23);
            returnpicbox.Name = "returnpicbox";
            returnpicbox.Size = new Size(100, 114);
            returnpicbox.SizeMode = PictureBoxSizeMode.Zoom;
            returnpicbox.TabIndex = 25;
            returnpicbox.TabStop = false;
            returnpicbox.Click += returnpicbox_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(128, 0, 32);
            label4.Location = new Point(9, 248);
            label4.Name = "label4";
            label4.Size = new Size(99, 19);
            label4.TabIndex = 22;
            label4.Text = "Book Title:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(128, 0, 32);
            label3.Location = new Point(7, 317);
            label3.Name = "label3";
            label3.Size = new Size(101, 19);
            label3.TabIndex = 21;
            label3.Text = "Book ISBN:";
            label3.Click += label3_Click_1;
            // 
            // returnbook_btn
            // 
            returnbook_btn.BackColor = Color.FromArgb(128, 0, 32);
            returnbook_btn.Cursor = Cursors.Hand;
            returnbook_btn.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            returnbook_btn.ForeColor = Color.WhiteSmoke;
            returnbook_btn.Location = new Point(50, 417);
            returnbook_btn.Name = "returnbook_btn";
            returnbook_btn.Size = new Size(134, 52);
            returnbook_btn.TabIndex = 19;
            returnbook_btn.Text = "Return";
            returnbook_btn.UseVisualStyleBackColor = false;
            returnbook_btn.Click += button1_Click;
            // 
            // returnbookisbn_txt
            // 
            returnbookisbn_txt.BorderStyle = BorderStyle.FixedSingle;
            returnbookisbn_txt.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            returnbookisbn_txt.Location = new Point(111, 314);
            returnbookisbn_txt.Name = "returnbookisbn_txt";
            returnbookisbn_txt.Size = new Size(118, 22);
            returnbookisbn_txt.TabIndex = 18;
            // 
            // returnbooktittle_txt
            // 
            returnbooktittle_txt.BorderStyle = BorderStyle.FixedSingle;
            returnbooktittle_txt.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            returnbooktittle_txt.Location = new Point(114, 245);
            returnbooktittle_txt.Name = "returnbooktittle_txt";
            returnbooktittle_txt.Size = new Size(118, 22);
            returnbooktittle_txt.TabIndex = 15;
            // 
            // returnissueid_txt
            // 
            returnissueid_txt.BorderStyle = BorderStyle.FixedSingle;
            returnissueid_txt.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            returnissueid_txt.Location = new Point(111, 179);
            returnissueid_txt.Name = "returnissueid_txt";
            returnissueid_txt.Size = new Size(118, 22);
            returnissueid_txt.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(128, 0, 32);
            label2.Location = new Point(7, 178);
            label2.Name = "label2";
            label2.Size = new Size(82, 19);
            label2.TabIndex = 10;
            label2.Text = "Issue ID:";
            // 
            // panel2
            // 
            panel2.BackColor = Color.WhiteSmoke;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(returndatagridview);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(264, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(593, 516);
            panel2.TabIndex = 1;
            // 
            // returndatagridview
            // 
            returndatagridview.AllowUserToAddRows = false;
            returndatagridview.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle1.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            returndatagridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            returndatagridview.BackgroundColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(128, 0, 32);
            dataGridViewCellStyle2.Font = new Font("Arial Rounded MT Bold", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            returndatagridview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            returndatagridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.Font = new Font("Arial Rounded MT Bold", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            returndatagridview.DefaultCellStyle = dataGridViewCellStyle3;
            returndatagridview.EnableHeadersVisualStyles = false;
            returndatagridview.Location = new Point(25, 52);
            returndatagridview.Name = "returndatagridview";
            returndatagridview.ReadOnly = true;
            returndatagridview.RowHeadersVisible = false;
            returndatagridview.Size = new Size(548, 442);
            returndatagridview.TabIndex = 19;
            returndatagridview.CellContentClick += returndatagridview_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(128, 0, 32);
            label1.Location = new Point(25, 12);
            label1.Name = "label1";
            label1.Size = new Size(205, 23);
            label1.TabIndex = 0;
            label1.Text = "All Borrowed Books:";
            // 
            // ReturnBooks
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "ReturnBooks";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)returnpicbox).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)returndatagridview).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private TextBox returnissueid_txt;
        private Label label2;
        private Button returnbook_btn;
        private Label label4;
        private Label label3;
        private TextBox returnbookisbn_txt;
        private TextBox returnbooktittle_txt;
        private PictureBox returnpicbox;
        private DataGridView returndatagridview;
    }
}
