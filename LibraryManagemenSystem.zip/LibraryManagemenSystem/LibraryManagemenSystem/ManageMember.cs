﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagemenSystem
{
    public partial class ManageMember : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\alii3\Documents\library.mdf;Integrated Security=True;Connect Timeout=30");
        public ManageMember()
        {
            InitializeComponent();
            membersgridview.CellClick += membergridview_CellClick;
            displayMember();
        }
        private int memberID = 0;
        List<Member> allmembers = new List<Member>();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void borrowdatagridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void displayMember()
        {
            allmembers = new List<Member>();

            try
            {
                if (connect.State == ConnectionState.Open)
                {
                    connect.Close();
                }
                connect.Open();
                string query = "SELECT * FROM users";

                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Member member = new Member
                            {
                                ID = reader.GetInt32(0),
                                Email = reader.GetString(1),
                                Name = reader.GetString(2),
                                Password = reader.GetString(3),
                                DateRegistered = reader.IsDBNull(4) ? (DateTime?)null : reader.GetDateTime(4) // Handle NULL for DateRegistered
                            };
                            allmembers.Add(member);
                        }
                        reader.Close();

                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                {
                    connect.Close();
                }
            }

            membersgridview.DataSource = allmembers;
            membersgridview.DefaultCellStyle.ForeColor = Color.Black;
            membersgridview.Refresh();
        }


        private void adminregister_Click(object sender, EventArgs e)
        {
            if (adminregister_email.Text == "" || adminregister_username.Text == "" || adminregister_password.Text == "")
            {
                MessageBox.Show("Pleasse fill all the blanks", "Err0r Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                
                
                    try
                    {
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                    connect.Open();

                        String checkUsername = "SELECT COUNT(*) FROM users WHERE username = @username";

                        using (SqlCommand checkCMD = new SqlCommand(checkUsername, connect))
                        {
                            checkCMD.Parameters.AddWithValue("@username", adminregister_username.Text.Trim());
                            int count = (int)checkCMD.ExecuteScalar();

                            if (count >= 1)
                            {

                                MessageBox.Show(adminregister_username.Text.Trim() +
                                    " IS ALREADY TAKEN", "Err0r Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                DateTime day = DateTime.Today;


                                String insertData = "INSERT INTo users (email,username,password,date_register)" +
                                    "VALUES(@email, @username, @password,@date)";

                                using (SqlCommand insertCMD = new SqlCommand(insertData, connect))
                                {
                                    insertCMD.Parameters.AddWithValue("@email", adminregister_email.Text.Trim());
                                    insertCMD.Parameters.AddWithValue("@username", adminregister_username.Text.Trim());
                                    insertCMD.Parameters.AddWithValue("@password", adminregister_password.Text.Trim());
                                    insertCMD.Parameters.AddWithValue("@date", day.ToString());

                                    insertCMD.ExecuteNonQuery();

                                    MessageBox.Show("Register successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    displayMember();
                                    clearFields();

                                }
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error connection DataBase: " + ex, "Err0r Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        

        private void deletemember_btn_Click(object sender, EventArgs e)
        {
            if (adminregister_email.Text == null || adminregister_username.Text == null 
              || adminregister_password.Text == null)
            {
                MessageBox.Show("Please select item first ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                
                
                    DialogResult check = MessageBox.Show("Are you sure you want to delete member ID : "+ 
                    memberID + "?"   , "Comfirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            string deleteData = "DELETE FROM users WHERE id=" + memberID;
                            using (SqlCommand cmd = new SqlCommand(deleteData, connect))
                            {
                                cmd.ExecuteNonQuery();

                                MessageBox.Show("Deleted  Successfully", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                displayMember();
                                clearFields();
                            }


                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close() ;
                        }
                    }
                }

            }

        
        public void clearFields()
        {
            adminregister_email.Text = "";
            adminregister_username.Text = "";
            adminregister_password.Text = "";
            
            membersgridview.Refresh();



        }
   
        private void membergridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.RowIndex >= 0) // Ensure it's a valid row index
                {
                    try
                    {
                        DataGridViewRow row = membersgridview.Rows[e.RowIndex];

                        // Assign values from DataGridView to TextBoxes
                        memberID = Convert.ToInt32(row.Cells[0].Value);

                        adminregister_email.Text = row.Cells[3].Value?.ToString() ?? "";
                        adminregister_username.Text = row.Cells[1].Value?.ToString() ?? "";
                        adminregister_password.Text = row.Cells[2].Value?.ToString() ?? "";

                        Member selectedMember = allmembers.FirstOrDefault(m => m.ID == memberID);
                        if (selectedMember != null)
                        {
                            selectedMember.BorrowedBooks = selectedMember.GetBorrowedBooks();
                        }


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        membersgridview.Refresh();
                        
                    }
                }
            }
        }
    }
}
