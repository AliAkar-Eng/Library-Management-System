﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagemenSystem
{
    public partial class MainForm : Form

    {


        public MainForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void adminbtn_Click(object sender, EventArgs e)
        {

        }

        public void HideAdminButton()
        {
            adminbtn.Visible = false;
        }
        public void HideAdminpic()
        {
            adminpic.Visible = false;
        }
        public void HideAdminpic2()
        {
            adminpic2.Visible = false;
        }
        public void HideAdminButton2()
        {
            adminmemberbtn.Visible = false;
        }



        private void adminpic_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void manageMember1_Load(object sender, EventArgs e)
        {

        }

       

        private void bookbtn_Click(object sender, EventArgs e)
        {
          
            borrowBooks1.Visible = true;
            manageMember1.Visible = false;
            updatebook1.Visible = false;
            returnBooks1.Visible = false;

        }

        private void returnbtn_Click(object sender, EventArgs e)
        {
          
            borrowBooks1.Visible = false;
            manageMember1.Visible = false;
            updatebook1.Visible = false;
            returnBooks1.Visible = true;

        }

        private void adminbtn_Click_1(object sender, EventArgs e)
        {
          
            borrowBooks1.Visible = false;
            manageMember1.Visible = false;
            updatebook1.Visible = true;
            returnBooks1.Visible = false;

        }
        public void hide1()
        {
            bookbtn.Visible = false;
            pictureBox1.Visible = false;
            returnbtn.Visible = false;
            pictureBox3.Visible = false;

            borrowBooks1.Visible = false;
            manageMember1.Visible = false;
            updatebook1.Visible = true;
            returnBooks1.Visible = false;

        }

        

        private void adminmemberbtn_Click(object sender, EventArgs e)
        {
           
            borrowBooks1.Visible = false;
            manageMember1.Visible = true;
            updatebook1.Visible = false;
            returnBooks1.Visible = false;

           
        }
    }
}
