﻿namespace LibraryManagemenSystem
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            adminpic2 = new PictureBox();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            adminmemberbtn = new Button();
            label4 = new Label();
            adminpic = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            bookbtn = new Button();
            returnbtn = new Button();
            adminbtn = new Button();
            manageMember1 = new ManageMember();
            updatebook1 = new Updatebook();
            returnBooks1 = new ReturnBooks();
            borrowBooks1 = new BorrowBooks();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)adminpic2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)adminpic).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(128, 0, 32);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1101, 35);
            panel1.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(1082, 9);
            label3.Name = "label3";
            label3.Size = new Size(15, 15);
            label3.TabIndex = 1;
            label3.Text = "X";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.WhiteSmoke;
            label2.Location = new Point(4, 6);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(276, 18);
            label2.TabIndex = 2;
            label2.Text = "Library Management System |Main Form";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(1227, 10);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(15, 15);
            label1.TabIndex = 1;
            label1.Text = "X";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(128, 0, 32);
            panel2.Controls.Add(adminpic2);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(adminmemberbtn);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(adminpic);
            panel2.Controls.Add(pictureBox2);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(bookbtn);
            panel2.Controls.Add(returnbtn);
            panel2.Controls.Add(adminbtn);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 35);
            panel2.Name = "panel2";
            panel2.Size = new Size(220, 714);
            panel2.TabIndex = 1;
            // 
            // adminpic2
            // 
            adminpic2.BackColor = Color.WhiteSmoke;
            adminpic2.BorderStyle = BorderStyle.FixedSingle;
            adminpic2.Image = Properties.Resources.management_icon_color_line_outline_vector_sign_linear_style_pictogram_isolated_on_white_symbol_logo_illustration_2E9K81M;
            adminpic2.Location = new Point(8, 542);
            adminpic2.Name = "adminpic2";
            adminpic2.Size = new Size(55, 45);
            adminpic2.SizeMode = PictureBoxSizeMode.Zoom;
            adminpic2.TabIndex = 15;
            adminpic2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = Properties.Resources.b7bc0375d09377ed5d92775b6c91f302;
            pictureBox1.Location = new Point(8, 343);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(55, 45);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(4, 602);
            button1.Name = "button1";
            button1.Size = new Size(75, 35);
            button1.TabIndex = 10;
            button1.Text = "Logout";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // adminmemberbtn
            // 
            adminmemberbtn.BackColor = Color.WhiteSmoke;
            adminmemberbtn.Location = new Point(15, 542);
            adminmemberbtn.Name = "adminmemberbtn";
            adminmemberbtn.Size = new Size(200, 45);
            adminmemberbtn.TabIndex = 19;
            adminmemberbtn.Text = "      Manage Members";
            adminmemberbtn.UseVisualStyleBackColor = false;
            adminmemberbtn.Click += adminmemberbtn_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.WhiteSmoke;
            label4.Location = new Point(44, 183);
            label4.Name = "label4";
            label4.Size = new Size(119, 19);
            label4.TabIndex = 5;
            label4.Text = "Welcome Back !";
            // 
            // adminpic
            // 
            adminpic.BackColor = Color.WhiteSmoke;
            adminpic.BorderStyle = BorderStyle.FixedSingle;
            adminpic.Image = Properties.Resources.update_arrows_stroke_icon_vector_8265582;
            adminpic.Location = new Point(7, 479);
            adminpic.Name = "adminpic";
            adminpic.Size = new Size(55, 45);
            adminpic.SizeMode = PictureBoxSizeMode.Zoom;
            adminpic.TabIndex = 12;
            adminpic.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.WhatsApp_Image_2025_01_24_at_11_10_01_47f2fb13;
            pictureBox2.Location = new Point(53, 43);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 100);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox3.BorderStyle = BorderStyle.FixedSingle;
            pictureBox3.Image = Properties.Resources.return_arrow_icon_over_white_background_line_style_vector_illustration_2C62RKP;
            pictureBox3.Location = new Point(8, 414);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(55, 45);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            // 
            // bookbtn
            // 
            bookbtn.BackColor = Color.WhiteSmoke;
            bookbtn.Location = new Point(15, 343);
            bookbtn.Name = "bookbtn";
            bookbtn.Size = new Size(200, 45);
            bookbtn.TabIndex = 16;
            bookbtn.Text = "Borrow Books";
            bookbtn.UseVisualStyleBackColor = false;
            bookbtn.Click += bookbtn_Click;
            // 
            // returnbtn
            // 
            returnbtn.BackColor = Color.WhiteSmoke;
            returnbtn.Location = new Point(15, 414);
            returnbtn.Name = "returnbtn";
            returnbtn.Size = new Size(200, 45);
            returnbtn.TabIndex = 17;
            returnbtn.Text = "Return Books";
            returnbtn.UseVisualStyleBackColor = false;
            returnbtn.Click += returnbtn_Click;
            // 
            // adminbtn
            // 
            adminbtn.BackColor = Color.WhiteSmoke;
            adminbtn.Location = new Point(15, 479);
            adminbtn.Name = "adminbtn";
            adminbtn.Size = new Size(200, 45);
            adminbtn.TabIndex = 18;
            adminbtn.Text = "Update Books";
            adminbtn.UseVisualStyleBackColor = false;
            adminbtn.Click += adminbtn_Click_1;
            // 
            // manageMember1
            // 
            manageMember1.BackColor = Color.WhiteSmoke;
            manageMember1.Location = new Point(221, 35);
            manageMember1.Name = "manageMember1";
            manageMember1.Size = new Size(877, 572);
            manageMember1.TabIndex = 2;
            // 
            // updatebook1
            // 
            updatebook1.BackColor = Color.WhiteSmoke;
            updatebook1.ForeColor = Color.WhiteSmoke;
            updatebook1.Location = new Point(221, 35);
            updatebook1.Name = "updatebook1";
            updatebook1.Size = new Size(880, 565);
            updatebook1.TabIndex = 3;
            // 
            // returnBooks1
            // 
            returnBooks1.BackColor = Color.WhiteSmoke;
            returnBooks1.Location = new Point(221, 35);
            returnBooks1.Name = "returnBooks1";
            returnBooks1.Size = new Size(880, 565);
            returnBooks1.TabIndex = 4;
            // 
            // borrowBooks1
            // 
            borrowBooks1.BackColor = Color.WhiteSmoke;
            borrowBooks1.Location = new Point(221, 35);
            borrowBooks1.Name = "borrowBooks1";
            borrowBooks1.Size = new Size(877, 565);
            borrowBooks1.TabIndex = 5;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1101, 749);
            Controls.Add(borrowBooks1);
            Controls.Add(returnBooks1);
            Controls.Add(updatebook1);
            Controls.Add(manageMember1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Cursor = Cursors.Hand;
            Font = new Font("Tahoma", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)adminpic2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)adminpic).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Label label4;
        private Button button1;
        private PictureBox adminpic2;
        private Button adminmemberbtn;
        private PictureBox adminpic;
        private PictureBox pictureBox3;
        private Button bookbtn;
        private PictureBox pictureBox1;
        private Button returnbtn;
        private Button adminbtn;
        private ManageMember manageMember1;
        private Updatebook updatebook1;
        private ReturnBooks returnBooks1;
        private BorrowBooks borrowBooks1;
    }
}