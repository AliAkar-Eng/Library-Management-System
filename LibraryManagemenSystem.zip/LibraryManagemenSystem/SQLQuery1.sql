﻿

CREATE TABLE users

(
	id INT PRIMARY KEY IDENTITY(1,1),
	email VARCHAR(MAX) NULL,
	username VARCHAR(MAX) NULL,
	password VARCHAR(MAX) NULL,
	date_register DATE NULL
)

SELECT * FROM users

CREATE TABLE dbo.books

(

id INT PRIMARY KEY IDENTITY(1,1),
book_title VARCHAR(MAX) NULL,
author VARCHAR(MAX) NULL,
ISBN VARCHAR(MAX) NULL,
status VARCHAR(MAX) NULL,
image VARCHAR(MAX)NULL

)

SELECT * FROM books

ALTER TABLE books
ADD copies INT NOT NULL DEFAULT 1;

CREATE TABLE borrowed_books (
    id INT PRIMARY KEY IDENTITY(1,1),
    member_id INT FOREIGN KEY REFERENCES users(id),
    book_id INT FOREIGN KEY REFERENCES books(id),
    borrow_date DATETIME DEFAULT GETDATE(),
    return_date DATETIME NULL
);
SELECT * FROM borrowed_books







